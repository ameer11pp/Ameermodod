<?php

include('conn.php');

// for maintainece mode
$sql1 ="select * from onoff where id=11";
$result1 = mysqli_query($conn, $sql1);
$userDetails1 = mysqli_fetch_assoc($result1);

// for ftext and status
$sql2 ="select * from _ftext where id=1";
$result2 = mysqli_query($conn, $sql2);
$userDetails2 = mysqli_fetch_assoc($result2);
?>

<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<div class="row">
    <div class="col-lg-12">
        <?= $this->include('Layout/msgStatus') ?>
    </div>
    
    <!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->
     <div class="col-lg-6">
        <div class="card mb-3">
               <div class="card-header p3"style="background: linear-gradient(0.9turn, #26FF00,#CC00FF, #FFFF00);" text-white">
                𝙼𝙾𝙳 𝚂𝙴𝚁𝚅𝙴𝚁 𝙾𝙽𝙻𝙸𝙽𝙴_𝙾𝙵𝙵𝙻𝙸𝙽𝙴
            </div>
            <div class="card-body">
                <?= form_open() ?>

                <input type="hidden" name="status_form" value="1">
                <div class="form-group mb-3">
                    <label for="status">𝙲𝚄𝚁𝚁𝙴𝙽𝚃 𝚂𝚃𝙰𝚃𝚄𝚂 » <font size="2" color ="#a39c9b"><?php echo $userDetails1['status']; ?></font></label>
                  
                  
    <div class="input-group mb-3">
  <div class="input-group-prepend">
    <div class="input-group-text">
        
      <input type="radio" id="radio" name="radios" value="1" aria-label="Checkbox for following text input" REQUIRED><font size="2"> 𝙾𝙽𝙻𝙸𝙽𝙴 𝚂𝙴𝚁𝚅𝙴𝚁</font>
      
    </div>
 </div>
 </div>

 
   <div class="input-group mb-3">
  <div class="input-group-prepend">
    <div class="input-group-text">
        
      <input type="radio" id="radio" name="radios" value="2" aria-label="Checkbox for following text input"><font size="2" REQUIRED> 𝙾𝙵𝙵𝙻𝙸𝙽𝙴 𝚂𝙴𝚁𝚅𝙴𝚁</font>
      
    </div>
    </div>
    </div>
    <label for="modname">𝙲𝚄𝚁𝚁𝙴𝙽𝚃_𝙾𝙵𝙵𝙻𝙸𝙽𝙴_𝙼𝚂𝙶 » <font size="2" color ="#a39c9b"><?php echo $userDetails1['myinput']; ?></font></label>


  <div class="input-group mb-3">
  <div class="input-group-prepend">
      
    <span class="input-group-text" id="inputGroup-sizing-default">𝙾𝙵𝙵𝙻𝙸𝙽𝙴 𝙼𝚂𝙶</span>
  </div>
 
      <textarea class="form-control" placeholder="𝙴𝙽𝚃𝙴𝚁 𝚂𝙴𝚁𝚅𝙴𝚁 𝙾𝙵𝙵 𝙼𝙴𝚂𝚂𝙰𝙶𝙴" name = "myInput" id="myInput" id="exampleFormControlTextarea1" rows="1"></textarea>
</div>
                  
                    
                    <?php if ($validation->hasError('modname')) : ?>
                        <small id="help-modname" class="text-danger"><?= $validation->getError('modname') ?></small>
                    <?php endif; ?>
                </div>
                   <div class="form-group my-2">
                    <button type="submit" class="card-header p3"style="background: linear-gradient(0.9turn, #26FF00,#CC00FF, #FFFF00);">𝚄𝙿𝙳𝙰𝚃𝙴 𝚂𝚃𝙰𝚃𝚄𝚂</button>
                </div>
                <?= form_close() ?>
            </div>
        </div>
    </div>
   
    <!----><!----><!----><!----><!----><!----><!----><!---->
    
    <div class="col-lg-6">
        <div class="card mb-3">
               <div class="card-header p3"style="background: linear-gradient(0.9turn, #26FF00,#CC00FF, #FFFF00);" text-white">
                𝙲𝙷𝙰𝙽𝙶𝙴 𝙼𝙾𝙳 𝙽𝙰𝙼𝙴
            </div>
            <div class="card-body">
                <?= form_open() ?>

                <input type="hidden" name="modname_form" value="1">
             
                <div class="form-group mb-3">
                    <label for="modname">𝙲𝚄𝚁𝚁𝙴𝙽𝚃 𝙼𝙾𝙳 𝙽𝙰𝙼𝙴 » <font size="2" color ="#a39c9b"><?php echo $row['modname']; ?></font></label>
                    <input type="text" name="modname" id="modname" class="form-control mt-2" placeholder="𝙴𝙽𝚃𝙴𝚁 𝙽𝙴𝚆 𝙼𝙾𝙳 𝙽𝙰𝙼𝙴" aria-describedby="help-modname" REQUIRED>
                    <?php if ($validation->hasError('modname')) : ?>
                        <small id="help-modname" class="text-danger"><?= $validation->getError('modname') ?></small>
                    <?php endif; ?>
                </div>
                <div class="form-group my-2">
                    <button type="submit" class="card-header p3"style="background: linear-gradient(0.9turn, #F50057, #F50057, #F50057);">𝚄𝙿𝙳𝙰𝚃𝙴 𝙼𝙾𝙳 𝙽𝙰𝙼𝙴</button>
                </div>
                <?= form_close() ?>
            </div>
        </div>
    </div>
    
    <!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->
    <!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->
    
    <div class="col-lg-6">
        <div class="card mb-3">
               <div class="card-header p3"style="background: linear-gradient(0.9turn, #26FF00,#CC00FF, #FFFF00);" text-white">
                𝙲𝙷𝙰𝙽𝙶𝙴 𝙼𝙾𝙳 𝙵𝙻𝙾𝙰𝚃𝙸𝙽𝙶 𝚃𝙴𝚇𝚃
            </div>
            <div class="card-body">
                <?= form_open() ?>

                <input type="hidden" name="_ftext" value="1">
                
                <label for="status">𝙲𝚄𝚁𝚁𝙴𝙽𝚃 𝙼𝙾𝙳 𝚂𝚃𝙰𝚃𝚄𝚂 » <font size="2" color ="#a39c9b"><?php echo $userDetails2['_status']; ?> </font> </label>
                
                    <div class="input-group mb-3">
  <div class="input-group-prepend">
    <div class="input-group-text">
        
      <input type="radio" id="radio" name="_ftextr" value="1" aria-label="𝙲𝙷𝙴𝙲𝙺𝙱𝙾𝚇 𝙵𝙾𝚁 𝙵𝙾𝙻𝙻𝙾𝚆𝙸𝙽𝙶 𝚃𝙴𝚇𝚃 𝙸𝙽𝙿𝚄𝚃" REQUIRED><font size="2"> 𝚂𝙰𝙵𝙴</font>
      
    </div>
 </div>
 </div>

 
   <div class="input-group mb-3">
  <div class="input-group-prepend">
    <div class="input-group-text">
        
      <input type="radio" id="radio" name="_ftextr" value="2" aria-label="𝙲𝙷𝙴𝙲𝙺𝙱𝙾𝚇 𝙵𝙾𝚁 𝙵𝙾𝙻𝙻𝙾𝚆𝙸𝙽𝙶 𝚃𝙴𝚇𝚃 𝙸𝙽𝙿𝚄𝚃"><font size="2" REQUIRED> 𝙽𝙾𝚃 𝚂𝙰𝙵𝙴</font>
      
    </div>
    </div>
    </div>
                
                <div class="form-group mb-3">
                    <label for="_ftext">𝙲𝚄𝚁𝚁𝙴𝙽𝚃 𝙵𝙻𝙾𝙰𝚃𝙸𝙽𝙶 𝚃𝙴𝚇𝚃 » <font size="2" color ="#a39c9b"><?php echo $userDetails2['_ftext']; ?></font></label>
                    <input type="text" name="_ftext" id="_ftext" class="form-control mt-2" placeholder="𝙴𝙽𝚃𝙴𝚁 𝙽𝙴𝚆 𝙵𝙻𝙾𝙰𝚃𝙸𝙽𝙶 𝚃𝙴𝚇𝚃" aria-describedby="help-_ftext" REQUIRED>
                    <?php if ($validation->hasError('_ftext')) : ?>
                        <small id="help-_ftext" class="text-danger"><?= $validation->getError('_ftext') ?></small>
                    <?php endif; ?>
                </div>
                <div class="form-group my-2">
                    <button type="Submit" class="card-header p3"style="background: linear-gradient(0.9turn, #26FF00,#CC00FF, #FFFF00);">𝚄𝙿𝙳𝙰𝚃𝙴 𝙵𝙻𝙾𝙰𝚃𝙸𝙽𝙶 𝚃𝙴𝚇𝚃 </button>
                </div>
                <?= form_close() ?>
            </div>
        </div>
    </div>
    
    <!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->
</div>

<?= $this->endSection() ?>