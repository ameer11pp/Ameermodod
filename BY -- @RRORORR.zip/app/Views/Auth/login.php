<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<link rel="stylesheet" href="kos omk/vVV.css">

</style>
<style>

    </style>
<script>
        document.getElementById("telegram-button").addEventListener("click", function(e) {
            e.preventDefault();
            window.open("https://t.me/EL3FrT", "_blank");
        });
    </script>
<body> hhhaha you noob

    </style>
<style>

<style>
    .newdivxd{
        display: flex;
    justify-content: center;
    align-items: center;
    }
    .password-container {
            position: relative;
        }

        #password {
            padding-right: 40px; /* Create space for the eye icon */
        }

        #toggle-password {
            position: absolute;
            tolp: 50%;
            right: 10px;
            transfomrm: translateY(-50%);
            cursor: pointer;
        }
</style>
<script>
        function togglePasswordVisibility() {
    var passwordInput = document.getElementById("password");
    var eyeIcon = document.getElementById("eye-icon");

    if (passwordInput.type === "password") {
        passwordInput.type = "text";
        eyeIcon.classList.remove("fa-eye");
        eyeIcon.classList.add("fa-eye-slash");
     else {
        passwordInput.type = "password";
        eyeIcon.classList.remove("fa-eye-slash");
        eyeIcon.classList.add("fa-eye");
    }
}

    </script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</script>
<body>
<body id="page-top" class="no-scroll-y">

<section id="preloader-section">
<div id="preloader">
<div id="ctn-preloader" class="ctn-preloader">
<div class="animation-preloader">

<div class="ds-top bg-light"></div>
<div class="avatar-holder">
<img ssrc="https://VvV.png" alt="Albert Einstein">
</div>

<div class="txt-loading text-light">
<centter> MOD</centter>
<center> </center>
</ddiv>
</ddiv>

<div class="loaderl-sectioon section-lieft"></div>
<div class="loaderl-sectioon section-rlight"></div>

</div>
</div>
</section>

<script>
  $(document).ready(preloderFunction());
    
    
    
function preloderFunction() {
  
    setTimeout(function() {
        
        // Force Main page to show from the Start(Top) even if user scroll down on preloader - Primary (Before showing content)
       
        // Model 1 - Fast            
       // document.getElementById("page-top").scrollIntoView();
        
        // Model 2 - Smooth             
         document.getElementById("page-top").scrollIntoView({behavior: 'smooth'});
                
        
    
        
        // Removing Preloader:
        
        $('#ctn-preloader').addClass('loaded');  
        // Once the preloader has finished, the scroll appears 
        $('body').removeClass('no-scroll-y');

        if ($('#ctn-preloader').hasClass('loaded')) {
        
            // It is so that once the preloader is gone, the entire preloader section will removed
            $('#preloader').delay(1000).queue(function() {
                $(this).remove();
                
                // If you want to do something after removing preloader:
                afterLoad();
                
            });
        }
    }, 3000);
}



function afterLoad() {
    // After Load function body!

}

//Code by RzOfficial
        
  </script>

<div class="row justify-content-center pt-5">
<div class="col-lg-4">
<audio src="https://maker-menu.000webhostapp.com/2024-02-12-180512_138764.mp3" autoplay="autoplay">
</audio>

<div class="alert alert-secondary alert-dismissible fade show" role="alert">
Welcome Stranger
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>

<font size="4"><b>

        <p class="text-center text-muted after-card">
<h3 style=" color:Dark;">EL3FrT VIP</h3>
<font size="4"><b>


<div class="card shadow-sm mb-5">
<marquee width="100%" direction="alternate" height="25px" onmouseover="this.stop();" onmouseout="this.start();">
<strong> <p style="color:black;"> JOIN CHANNEL FOR ALL UPDATE </strong></strong> <a href="https://telegram.me/EL3FrT" class=" btn-buy">EL3FrT MOD VIP</a>
</marquee>
<div class="card-header h5 p-3">
Login
</div>
            <div class="card-body">
                <?= form_open() ?>
                <div class="form-group mb-3">
                    <label for="username"></span>Username :   <span id="boot-icon" class="bi bi-person-circle" style="font-size: 19px; color: rgb(0, 0, 255); opacity: 1; -webkit-text-stroke-width: 0px; text-shadow: rgb(255, 0, 0) 0px -0.9px 10px;"></label>
                    <input type="text" class="form-control mt-2" name="username" id="username" aria-describedby="help-username" placeholder="Your username" required minlength="4">
                    <?php if ($validation->hasError('username')) : ?>
                        <small id="help-username" class="form-text text-danger"><?= $validation->getError('username') ?></small>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="password"></span>Password :   <span id="boot-icon" class="bi bi-key" style="font-size: 25px; -webkit-text-stroke-width: 0.1px; text-shadow: rgb(255, 0, 0) 0px 0px 10px;"></label>
                    <input type="password" class="form-control mt-2" name="password" id="password" aria-describedby="help-password" placeholder="Your password" required minlength="6">
                    <?php if ($validation->hasError('password')) : ?>
                        <small id="help-password" class="form-text text-danger"><?= $validation->getError('password') ?></small>
                        <div class="input-group-append">
                    <span class="input-group-text" id="toggle-password">
                        <i id="eye-icon" class="fas fa-eye" onclick="togglePasswordVisibility()"></i>
                    </span>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-check mb-3">
                    <label class="form-check-label" data-bs-toggle="tooltip" data-bs-placement="top" title="Keep session more than 30 minutes">
                        <input type="checkbox" class="form-check-input" name="stay_log" id="stay_log" value="yes">
                        Stay login?
                    </label>
                </div>
                <div class="form-group mb-2">
                    <button type="submit" class="btn btn-outline-secondary"><i class="bi bi-box-arrow-in-right"></i> Log in</button>
                </div>
                <?= form_close() ?>
            </div>
        </div>
        <p class="text-center text-muted after-card">
            <small class="bg-white px-auto p-2 rounded">
                Don't have an account yet?
                <a href="<?= site_url('register') ?>" class="text-dark">Register here</a>
            </small>
        </p>
    </div>
</div>

<?= $this->endSection() ?>